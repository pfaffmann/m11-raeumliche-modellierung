x=12;
y=5;
max(x,y)