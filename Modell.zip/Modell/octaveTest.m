clear all;
N = 2^31;
## The following line requires about 8 GB of RAM!
a = b = ones (N, 1);
c = a' * b